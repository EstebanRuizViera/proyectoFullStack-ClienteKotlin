package com.example.flight.tabMenu.myFlight;

data class Reservations(var name: String, var surname: String)
