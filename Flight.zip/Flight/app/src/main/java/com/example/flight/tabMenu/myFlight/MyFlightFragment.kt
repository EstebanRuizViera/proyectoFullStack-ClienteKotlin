package com.example.flight.tabMenu.myFlight

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.flight.R
import java.util.*


class MyFlightFragment : Fragment() {

    private lateinit var myFlightFragmentViewModel: MyFlightViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        myFlightFragmentViewModel =
            ViewModelProviders.of(this).get(MyFlightViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_my_flight, container, false)

        //1º) Quiero mostrar un conjunto de objetos. (P.Ej: ArrayList<Student>)
        val students: ArrayList<Reservations> = ArrayList<Reservations>()
        students.add(Reservations("Samuel", "Marrero"))
        students.add(Reservations("Francis", "Sosa"))
        students.add(Reservations("Gustavo", "Vega"))
        students.add(Reservations("Juan", "Sosa"))
        students.add(Reservations("Jacinto", "Ramos Moreno"))
        students.add(Reservations("Javier", "Santana"))
        students.add(Reservations("Olga", "Cruz"))

        //2º) Uso un RecyclerView para mostrar un conjunto de items en general.
        val recyclerViewStudents: RecyclerView = root.findViewById(R.id.recyclerViewStudents)

        //3º) Indico la disposición en la que se mostrarán los items en el RecyclerView (P.Ej: GridLayout de 2 columnas)
        val layoutManagerStudents: RecyclerView.LayoutManager = GridLayoutManager(root.context, 1)
        recyclerViewStudents.setLayoutManager(layoutManagerStudents)

        //4º) Asigno al RecyclerView el adaptador que relaciona a cada item con su objeto a mostrar.
        val studentsAdapter = StudentsAdapter(students)
        recyclerViewStudents.setAdapter(studentsAdapter)
        return root
    }
}